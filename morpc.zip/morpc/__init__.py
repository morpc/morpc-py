__version__ = "0.3.5"

from .morpc import *
import morpc.frictionless
import morpc.census
import morpc.plot
import morpc.color
import morpc.color.palette as palette
import morpc.rest_api
